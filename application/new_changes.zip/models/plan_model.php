<?php

class Plan_Model extends CI_Model {
    
    
    function __construct() 
    {
        parent::__construct();
        $this->_table = 'user_plan';
    }
   
   function get_plans()
   {
      $this->db->select('*');
      $this->db->from('user_plan');
      return $this->db->get()->result_array();
   } 
    
   function get_plan_details($where)
   {
	  $this->db->select('*');
      $this->db->from($this->_table );
      $this->db->where($where);
      $query = $this->db->get()->row_array();
      return $query;
   }
   
   
}
?>
